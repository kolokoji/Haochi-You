using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Collection : MonoBehaviour
{
    Rigidbody2D coll;
    public float bian;
    void Start()
    {
        
    }
    
    void Update()
    {
        
    }

    public virtual void Kick()
    {
        if (gameObject.CompareTag("Player"))
        {
            coll.AddForce(transform.right * bian);
        }
    }
}
