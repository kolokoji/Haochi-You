using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Enemy1 : Collection
{

    public TextMeshProUGUI text;
    
    public override void Kick()
    {
        base.Kick();
        if (gameObject.transform.position.x>0.7f)
        {
            text.text = "enemy1 is kicked";
            text.color = Color.red;
        }
        
    }

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Kick();
    }
}
