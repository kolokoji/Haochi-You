using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class healthBar : MonoBehaviour
{
    public Image Bar;
    public float health,maxhealth= 100;

    public void Update()
    {
        BarFiller();
    }
    public void BarFiller()
    {
        Bar.fillAmount = health / maxhealth;
    }

    public void AddHealth()
    {
        health += 10;
    }

    public void ReduceHealth()
    {
        health -= 10;
    }
}
